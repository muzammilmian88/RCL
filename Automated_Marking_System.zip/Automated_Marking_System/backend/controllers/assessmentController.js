const Assessment = require("../models/assessmentModel");
const path = require("path");

// GET all assessments
exports.getAssessments = async (req, res) => {
  try {
    const assessments = await Assessment.find();
    res.status(200).json(assessments);
  } catch (error) {
    res.status(500).json({ message: "Error fetching assessments", error });
  }
};

// Upload a file and associate with an assessment
exports.uploadFile = async (req, res) => {
  try {
    const { courseId } = req.body;
    const filePath = req.file ? `/uploads/${req.file.filename}` : null;

    // if (!filePath) {
    //   return res.status(400).json({ message: "File is required" });
    // }

    const assessment = await Assessment.findOneAndUpdate(
      { courseId },
      { filePath, status: "Submitted" },
      { new: true }
    );

    if (!assessment) {
      return res.status(404).json({ message: "Assessment not found" });
    }

    res.status(200).json({ message: "File uploaded successfully", assessment });
  } catch (error) {
    res.status(500).json({ message: "Error uploading file", error });
  }
};
