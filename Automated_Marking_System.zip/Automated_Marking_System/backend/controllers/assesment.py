from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from werkzeug.utils import secure_filename
import os

app = Flask(marking_system)


app.config["MONGO_URI"] = "mongodb://localhost:27017/markingSytem"  
mongo = PyMongo(app)
assessments_collection = mongo.db.assessments

# Folder to save uploaded files
UPLOAD_FOLDER = "./uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# GET all assessments
@app.route('/assessments', methods=['GET'])
def get_assessments():
    try:
        assessments = list(assessments_collection.find({}, {"_id": 0}))  # Exclude _id field for cleaner response
        return jsonify(assessments), 200
    except Exception as e:
        return jsonify({"message": "Error fetching assessments", "error": str(e)}), 500


# Upload a file and associate it with an assessment
@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        course_id = request.form.get('courseId')
        file = request.files.get('file')
        file_path = None

        if file:
            # Save the file securely
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(file_path)

        # Update the assessment with the file path
        updated_assessment = assessments_collection.find_one_and_update(
            {"courseId": course_id},
            {"$set": {"filePath": file_path, "status": "Submitted"}},
            return_document=True  # Return the updated document
        )

        if not updated_assessment:
            return jsonify({"message": "Assessment not found"}), 404

        return jsonify({"message": "File uploaded successfully", "assessment": updated_assessment}), 200
    except Exception as e:
        return jsonify({"message": "Error uploading file", "error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
