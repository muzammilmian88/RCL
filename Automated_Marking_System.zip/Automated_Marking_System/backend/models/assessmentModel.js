const mongoose = require("mongoose");

// Define schema
const assessmentSchema = new mongoose.Schema({
  courseId: {
    type: String,
   
  },
  courseTitle: {
    type: String,
  
  },
  courseCode: {
    type: String,
   
  },
  weightage: {
    type: String,
   
  },
  dueDate: {
    type: Date,
    
  },
  status: {
    type: String,
    default: "Pending",
  },
  filePath: {
    type: String,
    required: false,
  },
});

// Create model
const Assessment = mongoose.model("Assessment", assessmentSchema);

module.exports = Assessment;
