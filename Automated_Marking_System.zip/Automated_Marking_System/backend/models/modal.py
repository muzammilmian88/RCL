from pydantic import BaseModel, Field
from datetime import datetime
from pymongo import MongoClient

# MongoDB configuration
client = MongoClient("mongodb://localhost:27017/")  
db = client["marking_system"]  
assessments_collection = db["assessments"]

# Define the schema using Pydantic
class AssessmentModel(BaseModel):
    courseId: str = Field(..., description="The ID of the course")
    courseTitle: str = Field(..., description="The title of the course")
    courseCode: str = Field(..., description="The code of the course")
    weightage: str = Field(..., description="Weightage of the assessment")
    dueDate: datetime = Field(..., description="Due date of the assessment")
    status: str = Field(default="Pending", description="Status of the assessment")
    filePath: str = Field(default=None, description="Path to the uploaded file")

# Function to create an assessment
def create_assessment(data: dict):
    """
    Inserts a new assessment document into the collection.
    """
    validated_data = AssessmentModel(**data).dict()
    result = assessments_collection.insert_one(validated_data)
    return str(result.inserted_id)

# Function to fetch all assessments
def get_all_assessments():
    """
    Fetches all assessments from the collection.
    """
    return list(assessments_collection.find({}, {"_id": 0}))

# Example usage
if __name__ == "__main__":
    # Example assessment data
    example_data = {
        "courseId": "CS101",
        "courseTitle": "Introduction to Computer Science",
        "courseCode": "CS101",
        "weightage": "20%",
        "dueDate": "2024-12-31",
        "status": "Pending",
        "filePath": None,
    }

    # Insert a new assessment
    assessment_id = create_assessment(example_data)
    print(f"New assessment created with ID: {assessment_id}")

    # Fetch all assessments
    assessments = get_all_assessments()
    print("All assessments:", assessments)
