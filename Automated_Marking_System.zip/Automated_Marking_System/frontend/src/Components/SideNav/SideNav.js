import React, { useState } from "react";
import { Layout, Menu } from "antd";
import regent from "../../images/logo.png";
import { useNavigate, Outlet } from "react-router-dom";
import {

  DashboardOutlined,
  BookOutlined,
  CheckCircleOutlined,
  BarChartOutlined,
  SolutionOutlined,
} from "@ant-design/icons";

const { Header, Sider, Content } = Layout;

const SideNav = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  return (
    <Layout style={{ height: "100vh" }}>
      {/* Sidebar */}
      <Sider collapsible collapsed={collapsed} onCollapse={toggleCollapsed}>
        <div
          className="logo"
          style={{
            position: "relative",
            width: "100%",
            height: "55%",
            overflow: "hidden",
          }}
        >
          <img
            src={regent}
            alt="Logo"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "25.5%",
              objectFit: "cover",
            }}
          />
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          onClick={({ key }) => navigate(key)}
          style={{ marginTop: "-100%" }}
        >
          <Menu.Item key="/dashboard" icon={<DashboardOutlined />}>
            Dashboard
          </Menu.Item>
          <Menu.Item key="/all-courses" icon={<BookOutlined />}>
            All Courses
          </Menu.Item>
          <Menu.Item key="/assesments" icon={<CheckCircleOutlined />}>
            Assessments
          </Menu.Item>
          <Menu.Item key="/results" icon={<BarChartOutlined />}>
            Results
          </Menu.Item>
          <Menu.Item key="/marker" icon={<SolutionOutlined />}>
            Marker
          </Menu.Item>
        </Menu>
      </Sider>

      {/* Main Content */}
      <Layout>
        <Header
          style={{
            padding: 0,
            textAlign: "center",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height:'76px'
          }}
        >
         <h2
  style={{
    color: "#fff",
    fontSize: "36px", // Slightly larger for emphasis
    fontFamily: "'Poppins', sans-serif", // Stylish font
    fontWeight: 500,
    letterSpacing: "2px", // Slightly more spacing for elegance
    textShadow: "2px 2px 4px rgba(0, 0, 0, 0.6)", // Subtle shadow for depth
    // fontStyle: "italic", 
    fontFamily: "Abril Fatface",
    margin: 0, // Ensure it aligns perfectly
  }}
>
  {/* Regent College London */}
  Automated Marking System
</h2>

        </Header>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            background: "#fff",
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default SideNav;
