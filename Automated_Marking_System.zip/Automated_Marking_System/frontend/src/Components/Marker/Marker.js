import React, { useState } from "react";
import { Table, Button, Tag, Modal, Form, Input, notification } from "antd";
import { DownloadOutlined } from "@ant-design/icons";

const FileTable = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const dataSource = [
    {
      key: "1",
      id: "COM7301",
      studentName: "Muzammil",
      courseName: "Research Methods",
      status: "Pending",
      files: [{ name: "Research Methods.docx", url: "/files/Research Methods.docx" }],
    },
    {
      key: "2",
      id: "COM7302",
      studentName: "Bilal",
      courseName: "Software Engineering",
      status: "Completed",
      files: [{ name: "ProjectPlan.docx", url: "/files/AIMS SRS.docx" }],
    },
    {
      key: "3",
      id: "COM7303",
      studentName: "Yamesh",
      courseName: "Professional Practices",
      status: "Pending",
      files: [{ name: "CaseStudy.docx", url: "/files/CaseStudy.docx" }],
    },
  ];

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Student Name",
      dataIndex: "studentName",
      key: "studentName",
    },
    {
      title: "Course Name",
      dataIndex: "courseName",
      key: "courseName",
    },
    {
      title: "Files",
      dataIndex: "files",
      key: "files",
      render: (files) => (
        <>
          {files.map((file, index) => (
            <Button
              key={index}
              type="link"
              icon={<DownloadOutlined />}
              href={file.url}
              download
              style={{ marginRight: 8 }}
            >
              {file.name}
            </Button>
          ))}
        </>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag color={status === "Completed" ? "green" : "volcano"}>{status}</Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Button
          type="primary"
          onClick={() => handleAddRemarks(record)}
        >
          Add Remarks
        </Button>
      ),
    },
  ];

  const handleAddRemarks = (record) => {
    setSelectedRecord(record);
    setIsModalVisible(true);

    // Show notification when "Add Remarks" is clicked
    notification.info({
      message: "Add Remarks",
      description: `You are adding remarks for ${record.studentName}.`,
      placement: "topRight", // Notification appears in the top-right corner
    });
  };

  const handleOk = () => {
    setIsModalVisible(false);

    // Show success notification after submission
    notification.success({
      message: "Remarks Submitted",
      description: `Remarks for ${selectedRecord.studentName} have been successfully saved.`,
      placement: "topRight",
    });
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  return (
    <div style={{ padding: 24, background: "#fff", minHeight: "100vh" }}>
      <h2 style={{ textAlign: "center", marginBottom: 24 }}>Student Assessments</h2>

      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={{ pageSize: 5 }}
      />

      {/* Add Remarks Modal */}
      <Modal
        title={`Add Remarks for ${selectedRecord?.studentName || ""}`}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        okText="Submit"
        cancelText="Cancel"
      >
        <Form layout="vertical">
          <Form.Item
            label="Marks (out of 100)"
            name="marks"
            rules={[{ required: true, message: "Please enter the marks" }]}
          >
            <Input placeholder="Enter marks" type="number" />
          </Form.Item>
          <Form.Item
            label="Comments"
            name="comments"
            rules={[{ required: true, message: "Please add comments" }]}
          >
            <Input.TextArea placeholder="Add comments" rows={4} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default FileTable;
