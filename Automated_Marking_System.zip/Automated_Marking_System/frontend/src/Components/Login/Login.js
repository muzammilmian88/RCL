import React from 'react';
import { Form, Input, Button, Typography, Row, Col } from 'antd';
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import regent from "../../images/logo.png"; // Import the logo

const { Title } = Typography;

const Login = () => {
  const navigate = useNavigate(); // Initialize the navigate function

  const onFinish = (values) => {
    console.log('Success:', values);
    // Handle login logic here (e.g., API call for authentication)
    // If login is successful, navigate to the dashboard
    navigate('/dashboard');
  };

  const onFinishFailed = (errorInfo) => {
    console.error('Failed:', errorInfo);
  };

  return (
    <Row justify="center" align="middle" style={{ height: '100vh', backgroundColor: '#f0f2f5' }}>
      <Col xs={22} sm={16} md={12} lg={8} xl={6}>
        <div
          style={{
            padding: '24px',
            backgroundColor: '#fff',
            border: '1px solid #d9d9d9',
            borderRadius: '8px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
            textAlign: 'center',
          }}
        >
          {/* Logo */}
          <div style={{ marginBottom: 24 }}>
            <img src={regent} alt="Regent Logo" style={{ height: '80px' }} />
          </div>

          {/* Title */}
          <div style={{ marginBottom: 24 }}>
            <Title level={4} style={{ margin: 0 }}>
              Login to Your Account
            </Title>
          </div>

          {/* Login Form */}
          <Form
            name="login"
            initialValues={{ remember: true }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            layout="vertical"
          >
            {/* Username Field */}
            <Form.Item
              label="Username"
              name="username"
              rules={[{ required: true, message: 'Please enter your username!' }]}
            >
              <Input prefix={<UserOutlined />} placeholder="Username" />
            </Form.Item>

            {/* Password Field */}
            <Form.Item
              label="Password"
              name="password"
              rules={[{ required: true, message: 'Please enter your password!' }]}
            >
              <Input.Password prefix={<LockOutlined />} placeholder="Password" />
            </Form.Item>

            {/* Login Button */}
            <Form.Item>
              <Button type="primary" htmlType="submit" block>
                Login
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Col>
    </Row>
  );
};

export default Login;
