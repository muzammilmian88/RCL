import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./Components/Login/Login.js";
import SideNav from "./Components/SideNav/SideNav.js";
import Dashboard from "./Components/Dashboard/Dashboard.js";
import Assesments from "./Components/Assesments/Assesments.js";
import Marker from "./Components/Marker/Marker.js";
import Performa from "./Components/Performa/Performa.js";



const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<SideNav />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/assesments" element={<Assesments />} />
          <Route path="/marker" element={<Marker/>} />
          <Route path="/performa" element={<Performa/>} />

        </Route>
      </Routes>
    </Router>
  );
};

export default App;
