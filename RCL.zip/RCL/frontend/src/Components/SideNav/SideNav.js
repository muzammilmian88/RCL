import React, { useState } from "react";
import { Layout, Menu } from "antd";
import regent from "../../images/logo.png"; // Make sure this path is correct
import { useNavigate, Outlet } from "react-router-dom";
import {
  DashboardOutlined,
  BookOutlined,
  CheckCircleOutlined,
  BarChartOutlined,
  SolutionOutlined,
} from "@ant-design/icons";

const { Header, Sider, Content } = Layout;

const SideNav = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  return (
    <Layout style={{ minHeight: "100vh" }}>
      {/* Sidebar */}
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={toggleCollapsed}
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          bottom: 0,
          zIndex: 102, // Ensure the sidebar is above the header
          background: "#001529", // Match the sidebar color with the header
        }}
      >
        <div
          className="logo"
          style={{
            position: "relative",
            width: "100%",
            height: "80px", // Ensure a fixed height for the logo container
            overflow: "hidden",
            display: "flex",
            justifyContent: "center",
            alignItems: "center", // Centering the logo in the container
            marginBottom: "20px", // Adding some space below
            zIndex: 103, // Ensure the logo appears above the sidebar menu items
          }}
        >
          <img
            src={regent}
            alt="Logo"
            style={{
              maxWidth: "100%", // Ensure it fits within the container
              height: "auto",   // Maintain aspect ratio
              objectFit: "contain", // Ensure the image doesn't get stretched
            }}
          />
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          onClick={({ key }) => navigate(key)}
          style={{ marginTop: "20px", zIndex: 99 }} // Set zIndex lower than logo
        >
          <Menu.Item key="/dashboard" icon={<DashboardOutlined />}>
            Dashboard
          </Menu.Item>
          <Menu.Item key="/all-courses" icon={<BookOutlined />}>
            All Courses
          </Menu.Item>
          <Menu.Item key="/assesments" icon={<CheckCircleOutlined />}>
            Assessments
          </Menu.Item>
          <Menu.Item key="/results" icon={<BarChartOutlined />}>
            Results
          </Menu.Item>
          <Menu.Item key="/marker" icon={<SolutionOutlined />}>
            Marker
          </Menu.Item>
          <Menu.Item key="/performa" icon={<BookOutlined />}>
            Performa
          </Menu.Item>
        </Menu>
      </Sider>

      {/* Main Content */}
      <Layout style={{ marginLeft: collapsed ? 80 : 200 }}>
        <Header
          style={{
            padding: 0,
            textAlign: "center",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: "76px",
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            zIndex: 101, // Ensure header is below the sidebar
            backgroundColor: "#001529", // Match Ant Design's default header color
          }}
        >
          <h2
            style={{
              color: "#fff",
              fontSize: "36px", // Slightly larger for emphasis
              fontFamily: "'Poppins', sans-serif", // Stylish font
              fontWeight: 500,
              letterSpacing: "2px", // Slightly more spacing for elegance
              textShadow: "2px 2px 4px rgba(0, 0, 0, 0.6)", // Subtle shadow for depth
              margin: 0, // Ensure it aligns perfectly
            }}
          >
            Automated Marking System
          </h2>
        </Header>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            background: "#fff",
            marginTop: "76px", // To prevent content from hiding under the fixed header
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default SideNav;
