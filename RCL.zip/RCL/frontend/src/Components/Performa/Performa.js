import React from "react";
import { Form, Input, Typography, Table, Row, Col } from "antd";

const { Title } = Typography;

const Performa = () => {
  // Data for the first table (user info table)
  const dataSource = [
    { key: "1", field: "Paper Id", input: <Input placeholder="Enter Paper Id" /> },
    { key: "2", field: "Marker Name", input: <Input placeholder="Enter Marker Name" /> },
    { key: "3", field: "Marker Signature", input: <Input placeholder="Enter Marker Signature" /> },
    { key: "4", field: "Marks", input: <Input placeholder="Enter Marks" type="number" /> },
  ];

  const columns = [
    {
      dataIndex: "field",
      key: "field",
      width: "30%", // Reduced width
      render: (text) => <span style={{ fontWeight: "bold", color: "#4a4a4a" }}>{text}</span>,
    },
    {
      dataIndex: "input",
      key: "input",
      width: "30%", // Reduced width
      render: (input) => <div style={{ padding: "4px" }}>{input}</div>,
    },
  ];

  // Data for the second table (research info table)
  const tableData = [
    {
      key: "1",
      col1: "INTRODUCTION, CONTEXT, RESEARCH OBJECTIVES",
      col2: "(10%)",
      col3: "MARKING CRITERIA\n• Is the research topic or problem clearly stated and shown to be worth investigating?\n• Has appropriate background information been provided with special terms and concepts defined?\n• Are the research objectives (research questions or hypotheses) clear, relevant, coherent and achievable?\n• Do objectives etc. go beyond mere description i.e. Do they involve explanation, comparison, criticism, or evaluation?",
    },
  ];

  const columns2 = [
    {
      title: "Criteria",
      dataIndex: "col1",
      key: "col1",
      render: (text) => <strong>{text}</strong>,
      width: "30%", // Ensure this column has a fixed width
    },
    {
      title: "Marks",
      dataIndex: "col2",
      key: "col2",
      render: (text) => <span>{text}</span>,
      width: "10%", // Adjust width if needed
    },
    {
      title: "Details",
      dataIndex: "col3",
      key: "col3",
      render: (text) => (
        <div
          style={{
            whiteSpace: "pre-wrap", // Ensure text wraps instead of overflowing
            wordBreak: "break-word", // Break long words if necessary
            fontSize: "12px",
            lineHeight: "1.5",
            color: "#4a4a4a",
          }}
        >
          {text}
        </div>
      ),
      width: "60%", // Adjust width to fit the content
    },
  ];

  // Data for the third table (input table)
  const tableDataInput = [
    {
      key: "1",
      col1: "Marks",
      col2: <Input />,
    },
  ];

  const columnsInput = [
    {
     
      dataIndex: "col1",
      key: "col1",
    },
    {
     
      dataIndex: "col2",
      key: "col2",
    },
  ];

  return (
    <div
      style={{
        padding: 15,
        background: "#f0f2f5",
        minHeight: "50vh",
        maxWidth: "80%",
        borderRadius: "8px",
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
        overflowY: "auto",
        margin: "0 auto",
      }}
    >
      <Title level={4} style={{ textAlign: "center", marginBottom: 14,  }}>
        Dissertation Marking Proforma
      </Title>

      {/* First Table (User Info Table) */}
      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={false}
        bordered
        style={{ backgroundColor: "#ffffff", border: "1px solid #d9d9d9", fontSize: "12px", marginBottom: "20px" }}
        tableLayout="fixed" // Prevent horizontal scroll in the table
      />

      {/* Second Table (Research Info Table) */}
      <Table
        dataSource={tableData}
        columns={columns2}
        pagination={false}
        bordered
        style={{ backgroundColor: "#ffffff", border: "1px solid #d9d9d9", fontSize: "12px", marginBottom: "20px" }}
        tableLayout="fixed" // Prevent horizontal scroll in the table
      />

      {/* Third Table (Input Table) */}
      <Table
        dataSource={tableDataInput}
        columns={columnsInput}
        pagination={false}
        bordered
        style={{ backgroundColor: "#ffffff", border: "1px solid #d9d9d9", fontSize: "12px" }}
        tableLayout="fixed" // Prevent horizontal scroll in the table
      />
    </div>
  );
};

export default Performa;
