import React, { useState } from "react";
import { Layout, Table, Modal, Button, Upload, Form, Input, Tag, notification } from "antd";
import { UploadOutlined } from "@ant-design/icons";

const { Content } = Layout;

const Assesments = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);

  const dataSource = [
    {
      key: "1",
      id: "101",
      title: "Research Methods",
      code: "COM101",
      weightage: "20%",
      dueDate: "2024-12-01",
      status: "Pending",
    },
    {
      key: "2",
      id: "102",
      title: "Software Engineering",
      code: "COM102",
      weightage: "30%",
      dueDate: "2024-12-10",
      status: "Submitted",
    },
    {
      key: "3",
      id: "103",
      title: "Professional Practices",
      code: "COM103",
      weightage: "15%",
      dueDate: "2024-11-30",
      status: "Pending",
    },
  ];

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Course Title",
      dataIndex: "title",
      key: "title",
    },
    {
      title: "Course Code",
      dataIndex: "code",
      key: "code",
    },
    {
      title: "Weightage",
      dataIndex: "weightage",
      key: "weightage",
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDate",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag color={status === "Submitted" ? "green" : "volcano"}>
          {status}
        </Tag>
      ),
    },
  ];

  const handleRowClick = (record) => {
    setSelectedCourse(record);
    setIsModalVisible(true);
  };

  const handleFileChange = (info) => {
    const file = info.fileList[0]?.originFileObj;
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleOk = () => {
    if (!uploadedFile) {
      // Show error notification if no file is uploaded
      notification.error({
        message: "File Upload Error",
        description: "Please upload a file before saving.",
        placement: "topRight",
      });
      return;
    }

    // Save file logic
    const fileURL = URL.createObjectURL(uploadedFile);
    const link = document.createElement("a");
    link.href = fileURL;
    link.download = uploadedFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Show success notification
    notification.success({
      message: "File Saved",
      description: `The file "${uploadedFile.name}" has been saved successfully.`,
      placement: "topRight",
    });

    setUploadedFile(null);
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setUploadedFile(null);
    setIsModalVisible(false);
  };

  return (
    <Layout>
      <Content style={{ margin: "24px 16px", padding: 24, background: "#fff" }}>
        <h2 style={{ textAlign: "center" }}>Courses Table</h2>

        <Table
          dataSource={dataSource}
          columns={columns}
          onRow={(record) => ({
            onClick: () => handleRowClick(record),
          })}
          pagination={{ pageSize: 5 }}
        />

        <Modal
          title={`Upload File for ${selectedCourse?.title || "Course"}`}
          visible={isModalVisible}
          onOk={handleOk}
          onCancel={handleCancel}
          footer={[
            <Button key="cancel" onClick={handleCancel}>
              Cancel
            </Button>,
            <Button key="submit" type="primary" onClick={handleOk}>
              Save File
            </Button>,
          ]}
        >
          <Form>
            <Form.Item label="Course Title">
              <Input value={selectedCourse?.title} disabled />
            </Form.Item>
            <Form.Item label="Upload File">
              <Upload
                beforeUpload={() => false} // Prevents upload to server
                onChange={handleFileChange} // Sets file to state
                fileList={uploadedFile ? [uploadedFile] : []} // Display selected file
              >
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>
          </Form>
        </Modal>
      </Content>
    </Layout>
  );
};

export default Assesments;
