import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, PieChart, Pie, Cell } from "recharts";

const Dashboard = () => {
  // Data for Assessments (Total, Pending, Completed)
  const assessmentsData = [
    { category: "Total Assessments", count: 50 },
    { category: "Pending", count: 20 },
    { category: "Completed", count: 30 },
  ];

  // Data for Course Performance
  const coursePerformanceData = [
    { course: "Software Engineering", performance: 85 },
    { course: "Research Methods", performance: 78 },
    { course: "Professional Practices", performance: 92 },
  ];

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center" }}>Student Performance Dashboard</h2>
      <div style={{ display: "flex", justifyContent: "space-around", flexWrap: "wrap", gap: "16px" }}>
        {/* Pie Chart for Assessments */}
        <div style={{ width: "45%", minWidth: "300px" }}>
          <h3>Assessments Overview</h3>
          <PieChart width={400} height={300}>
            <Pie
              data={assessmentsData}
              dataKey="count"
              nameKey="category"
              cx="50%"
              cy="50%"
              outerRadius={100}
              fill="#8884d8"
              label
            >
              {assessmentsData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </div>

        {/* Bar Chart for Course Performance */}
        <div style={{ width: "45%", minWidth: "300px" }}>
          <h3>Course Performance</h3>
          <BarChart width={400} height={300} data={coursePerformanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="course" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="performance" fill="#00C49F" />
          </BarChart>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
