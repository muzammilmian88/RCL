import express from 'express';
import multer from 'multer';
import { createAssesment, getAllAssessments, getAssessmentById, deleteAssessmentById, updateAssessmentById } from '../controllers/assesment.js';

const uploadfile=multer({
  storage:multer.diskStorage({
    destination:function(req,file,callback){  
      callback(null,'./uploads');
    },
    filename:function(req,file,callback){
      callback(null,Date.now()+"-"+file.originalname)
    }
  })
}).single('file');

const router= express.Router();

router.post('/',uploadfile,createAssesment);
router.get('/', getAllAssessments);
router.get('/:id', getAssessmentById);
router.delete('/:id', deleteAssessmentById);
router.patch('/:id', updateAssessmentById);

export default router;