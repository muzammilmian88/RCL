import { assesmentSchema } from "../Validations/index.js";
import Assesment from "../models/assesment.js";


export const createAssesment= async (req, res)=>{   
    const {title}=req.body;
    try{
        const { error, value } = assesmentSchema.validate(req.body);

        if (error) 
            return res.status(400).json({ message: error.details[0].message });

        if(!req.file || Object.keys(req.file).length === 0)
            return res.status(400).json({message: "No file found."});
        
        const file = req.file; 
        console.log(file.path)
       
       const UploadAssesmemnt= new Assesment({title,file:file.path});
        const savedAssessment = await UploadAssesmemnt.save();
        if (savedAssessment) {
            return res.status(200).json({ message: 'Assessment added Successfully.' });
        } else {
            return res.status(500).json({ message: "Unable to add Assessment." });
        }

    }catch(error){
        // If an error occurs during the process, return a 500 status with the error message
        console.error('Error creating user:', error);
        return res.status(500).json({ message: error });
    }
}

export const getAllAssessments = async (req, res) => {
    try {
        const assessments = await Assesment.find();
        assessments.forEach(assessment => {
            assessment.file = `http://localhost:5000/${assessment.file}`;
        });
        return res.status(200).json(assessments);
    } catch (error) {
        console.error('Error fetching assessments:', error);
        return res.status(500).json({ message: error });
    }
};

export const getAssessmentById = async (req, res) => {
    const { id } = req.params;
    try {
        const assessment = await Assesment.findById(id);
        if (!assessment) {
            return res.status(404).json({ message: "Assessment not found." });
        }
        assessment.file = `http://localhost:5000/${assessment.file}`;
        return res.status(200).json(assessment);
    } catch (error) {
        console.error('Error fetching assessment:', error);
        return res.status(500).json({ message: error });
    }
};

export const deleteAssessmentById = async (req, res) => {
    const { id } = req.params;
    try {
        const deletedAssessment = await Assesment.findByIdAndDelete(id);
        if (!deletedAssessment) {
            return res.status(404).json({ message: "Assessment not found." });
        }
        return res.status(200).json({ message: "Assessment deleted successfully." });
    } catch (error) {
        console.error('Error deleting assessment:', error);
        return res.status(500).json({ message: error });
    }
};

export const updateAssessmentById = async (req, res) => {
    const { id } = req.params;
    const { title, file } = req.body; // Assuming you want to update title and file
    try {
        const updatedAssessment = await Assesment.findByIdAndUpdate(id, { title, file }, { new: true });
        if (!updatedAssessment) {
            return res.status(404).json({ message: "Assessment not found." });
        }
        return res.status(200).json(updatedAssessment);
    } catch (error) {
        console.error('Error updating assessment:', error);
        return res.status(500).json({ message: error });
    }
};


