import Users from "../models/users.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { addUserSchema, loginSchema } from "../Validations/index.js";


export const Signin = async (req, res)=>{
    const {email,password} = req.body;
    try{
      const { error, value } = loginSchema.validate(req.body);

      if (error) {
        return res.status(400).json({ message: error.details[0].message });
      }

      const user=await Users.findOne({email});
      if(!user)
          return res.status(404).json({message:"User Not found"});
      
      
      const passwordMatched =await bcrypt.compare(password,user.password);
      if(!passwordMatched)
          return res.status(404).json({message: "Incorrrect Password"})

      const token= jwt.sign(
          {
              id:user._id,
              email:user.email,
              role:user.role
          },
          "Signin",
          {
              expiresIn: "3d"
          }
      );
      
      return res.status(200).json({message:"Signin Successfully...",token,role:user.role})

    }catch(error){
      console.log(error)
        return res.status(500).json({message:error})
    }
};

export const Signup= async (req, res)=>{   
    
  const {email,password}=req.body;
  const user=req.body;
  try{
      const { error } = addUserSchema.validate(req.body);
      if (error) {
          return res.status(400).json({ message: error.details[0].message });
      }
     
      const existingUser= await Users.findOne({email});
      if (existingUser)
          return res.status(400).json({ message:"User already exits..."});

      // const password=generatePassword(8)
      const hashPassword = await bcrypt.hash(password, 10);
      const NewUser= new Users({...user,password:hashPassword});
      const savedUser = await NewUser.save();

      // Check if the user was successfully added
      if (savedUser) {
          let message=`<p>Your Account has Created Successfully. Your Credentials for login are: <br> <b>Email</b>: ${email} <br> <b>Password</b>: ${password}</p>`

          SendEmail(email,"Account Creation",message);
          const token= jwt.sign(
            {
                id:savedUser._id,
                email:savedUser.email,
                role:savedUser.role
            },
            "Signin",
            {
                expiresIn: "3d"
            }
        );
        // Return a 200 status with a success message
        return res.status(200).json({ message: 'User Created Successfully.',token,role:savedUser.role });
      } else {
        // If for some reason the user was not saved, return a 500 status
        return res.status(500).json({ message: "Unable to add User." });
      }

  }catch(error){
      // If an error occurs during the process, return a 500 status with the error message
      console.error('Error creating user:', error);
      return res.status(500).json({ message: error });
  }
}

  
